# FR Core Organization Extension - Membre d'organisation - Guide d'implémentation Fr Core v2.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FR Core Organization Extension - Membre d'organisation**

## Extension: FR Core Organization Extension - Membre d'organisation 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/fhir/StructureDefinition/organization-member | *Version*:2.1.0 |
| Active as of 2025-11-02 | *Computable Name*:FRCoreOrganizationMemberExtension |

Extension permettant de définir des membres d’une organisation.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [FR Core Organization Profile](StructureDefinition-fr-core-organization.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.fr.core|current/StructureDefinition/fr-core-organization-member)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-core-organization-member.csv), [Excel](StructureDefinition-fr-core-organization-member.xlsx), [Schematron](StructureDefinition-fr-core-organization-member.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-core-organization-member",
  "url" : "http://example.org/fhir/StructureDefinition/organization-member",
  "version" : "2.1.0",
  "name" : "FRCoreOrganizationMemberExtension",
  "title" : "FR Core Organization Extension - Membre d'organisation",
  "status" : "active",
  "date" : "2025-11-02T16:31:57+01:00",
  "publisher" : "Interop'Santé",
  "contact" : [
    {
      "name" : "Interop'Santé",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://interopsante.org/"
        }
      ]
    },
    {
      "name" : "InteropSanté",
      "telecom" : [
        {
          "system" : "email",
          "value" : "fhir@interopsante.org",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "Extension permettant de définir des membres d'une organisation.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "FR",
          "display" : "France"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [
    {
      "type" : "element",
      "expression" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization#Organization"
    }
  ],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Extension",
        "path" : "Extension",
        "short" : "FR Core Organization Extension - Membre d'organisation",
        "definition" : "Extension permettant de définir des membres d'une organisation."
      },
      {
        "id" : "Extension.extension:member",
        "path" : "Extension.extension",
        "sliceName" : "member",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:member.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:member.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "member"
      },
      {
        "id" : "Extension.extension:member.value[x]",
        "path" : "Extension.extension.value[x]",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "Extension.extension:member.value[x]:valueReference",
        "path" : "Extension.extension.value[x]",
        "sliceName" : "valueReference",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization"
            ]
          }
        ]
      },
      {
        "id" : "Extension.url",
        "path" : "Extension.url",
        "fixedUri" : "http://example.org/fhir/StructureDefinition/organization-member"
      },
      {
        "id" : "Extension.value[x]",
        "path" : "Extension.value[x]",
        "max" : "0"
      }
    ]
  }
}

```
