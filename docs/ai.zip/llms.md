# hl7.fhir.fr.core#2.1.0: Guide d'implémentation Fr Core

## Pages

* [Accueil](index.md)
* [Nomenclatures](structure_nomenclatures.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](downloads.md)
* [Introduction](structure_intro.md)
* [Entités](structure_entites.md)
* [Liste des profils](profile_list.md)
* [Contraintes sur les profils](structure_contraintes.md)
* [Références](structure_ref_loi.md)
* [Bonnes pratiques](bonnes_pratiques.md)
* [A propos](a_propos.md)
* [Artifacts Summary](artifacts.md)
* [Relations entre entités](structure_relations.md)

## Resources

### CodeSystems

* [FR Core CodeSystem Champ Activite - Codes du champ d'activité](CodeSystem-fr-core-cs-champ-activite.md)
* [FR Core CodeSystem Codes Tarifs - nomenclature TNJP](CodeSystem-fr-core-cs-code-tarif-tnjp.md)
* [FR Core CodeSystem Discipline d'Equipement - nomenclature SAE](CodeSystem-fr-core-cs-discipline-equipement.md)
* [FR Core CodeSystem Discipline de prestation - nomenclature SAE](CodeSystem-fr-core-cs-discipline-prestation.md)
* [FR Core CodeSystem Position du lit](CodeSystem-fr-core-cs-location-position-lit.md)
* [FR Core CodeSystem Type Chambre](CodeSystem-fr-core-cs-location-type-chambre.md)
* [FR Core CodeSystem Location Type](CodeSystem-fr-core-cs-location-type.md)
* [FR Core CodeSystem Type d'activité - nomenclature SAE](CodeSystem-fr-core-cs-type-activite.md)
* [FR Core CodeSystem UF Indicator - indicateur d'une unité fonctionnelle](CodeSystem-fr-core-cs-uf-indicateur.md)
* [FR Core CodeSystem v2-3307](CodeSystem-fr-core-cs-v2-3307.md)

### ValueSets

* [FR Core ValueSet Categorie SAE Etablissement](ValueSet-fr-core-vs-categorie-sae-etablissement.md)
* [FR Core ValueSet Organization Discipline de prestation - nomenclature SAE](ValueSet-fr-core-vs-discipline-prestation.md)
* [FR Core ValueSet Email type](ValueSet-fr-core-vs-email-type.md)
* [FR Core ValueSet INSEE code](ValueSet-fr-core-vs-insee-code.md)
* [FR Core ValueSet Location Position Lit](ValueSet-fr-core-vs-location-position-lit.md)
* [FR Core ValueSet Location Type Chambre](ValueSet-fr-core-vs-location-type-chambre.md)
* [FR Core ValueSet Location type](ValueSet-fr-core-vs-location-type.md)
* [FR Core ValueSet Codes Tarifs - nomenclature TNJP](ValueSet-fr-core-vs-oragnization-code-tarif-tnjp.md)
* [FR Core ValueSet Organization Type Activité - nomenclature SAE](ValueSet-fr-core-vs-oragnization-type-activite.md)
* [FR Core ValueSet Organization Champ Activite - Champ d'activité clinique de l'organisation type UF](ValueSet-fr-core-vs-organization-champ-activite.md)
* [FR Core ValueSet Organization Discipline d'Equipement - nomenclature SAE](ValueSet-fr-core-vs-organization-discipline-equipement.md)
* [FR Core ValueSet Organization Etablisement type](ValueSet-fr-core-vs-organization-etablissement-type.md)
* [FR Core ValueSet Organization identifier type](ValueSet-fr-core-vs-organization-identifier-type.md)
* [FR Core ValueSet Organization type](ValueSet-fr-core-vs-organization-type.md)
* [FR Core ValueSet Organization UAC type](ValueSet-fr-core-vs-organization-uac-type.md)
* [FR Core ValueSet Organization UF type](ValueSet-fr-core-vs-organization-uf-indicateur.md)
* [FR Core ValueSet Organization UF type](ValueSet-fr-core-vs-organization-uf-type.md)

### Complex-type Profiles

* [FR Core Address Profile](StructureDefinition-fr-core-address.md)
* [FR Core Contact Point Profile](StructureDefinition-fr-core-contact-point.md)

### Resource Profiles

* [FR Core Location Profile](StructureDefinition-fr-core-location.md)
* [FR Core Organization Etablissement Profile](StructureDefinition-fr-core-organization-etablissement.md)
* [FR Core Organization UAC Profile](StructureDefinition-fr-core-organization-uac.md)
* [FR Core Organization UF Profile](StructureDefinition-fr-core-organization-uf.md)
* [FR Core Organization Profile](StructureDefinition-fr-core-organization.md)

### Extensions

* [FR Core Address Insee Code Extension](StructureDefinition-fr-core-address-insee-code.md)
* [FR Core Contact Point Email Type Extension](StructureDefinition-fr-core-contact-point-email-type.md)
* [FR Core Location Extension - Position du lit](StructureDefinition-fr-core-location-position-lit.md)
* [FR Core Location Extension - Type de chambre](StructureDefinition-fr-core-location-type-chambre.md)
* [FR Core Organization Extension - Champ d'activité](StructureDefinition-fr-core-organization-champ-activite.md)
* [FR Core Organization Extension - Demandeuse d'acte](StructureDefinition-fr-core-organization-demandeuse-acte.md)
* [FR Core Organization Description Extension](StructureDefinition-fr-core-organization-description.md)
* [FR Core Organization Extension - Discipline d'équipement](StructureDefinition-fr-core-organization-discipline-equipement.md)
* [FR Core Organization Extension - Discipline Prestation](StructureDefinition-fr-core-organization-discipline-prestation.md)
* [FR Core Organization Extension - Exécutante d'acte](StructureDefinition-fr-core-organization-executante-acte.md)
* [FR Core Organization Extension - Membre d'organisation](StructureDefinition-fr-core-organization-member.md)
* [FR Core Organization Extension - Nombre total de places d'hébergement théoriques](StructureDefinition-fr-core-organization-place-hebergement-theorique.md)
* [FR Core Organization Raison Sociale Extension](StructureDefinition-fr-core-organization-raison-sociale.md)
* [FR Core Organization Extension - Catetgorie SAE](StructureDefinition-fr-core-organization-sae-category.md)
* [FR Core Organization Short Name Extension](StructureDefinition-fr-core-organization-short-name.md)
* [FR Core Organization Extension - Tarif Soin](StructureDefinition-fr-core-organization-tarif.md)
* [FR Core Organization Extension - Type d'activité](StructureDefinition-fr-core-organization-type-activite.md)
* [FR Core Organization Extension - UF Externe](StructureDefinition-fr-core-organization-uf-externe.md)
* [FR Core Organization Extension - Indicateur d'une unité fonctionnelle](StructureDefinition-fr-core-organization-uf-indicateur.md)

### ImplementationGuides

* [Guide d'implémentation Fr Core](index.md)

### Examples

* [Depertement d'Endocrinologie (Organization)](Organization-hopitaltest-dept-11003-endocrino.md)
* [CHRU CENTRE VILLE (Organization)](Organization-hopitaltest-eg-4-members.md)
* [CHRU RENNES (Organization)](Organization-hopitaltest-ej-350005179.md)
* [Pole Medecines spécialisées (Organization)](Organization-hopitaltest-pole-1150-med-spe.md)
* [Service Endocrino Diabeto (Organization)](Organization-hopitaltest-service-11006-endocrino-diabo.md)
* [Service Dietetique (Organization)](Organization-hopitaltest-service-11007-dietetique.md)
* [UAC 01 Dialyse (Organization)](Organization-hopitaltest-uac-4420-uac-01.md)
* [UAC 02 Dialyse (Organization)](Organization-hopitaltest-uac-4420-uac-02.md)
* [UF Dialyse (Organization)](Organization-hopitaltest-uf-4420-dialyse.md)
* [UF Endocrino Diabeto (Organization)](Organization-hopitaltest-uf-4701-endocrino-diab.md)
* [UF Nutrition (Organization)](Organization-hopitaltest-uf-4705-nutrition.md)
